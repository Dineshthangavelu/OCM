package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Lpocm__ LP_ OCM_ Cancel Workflow Page"                                
               , summary=""
               , page="LP_OCM_CancelWorkflowPage"
               , namespacePrefix="LPOCM"
               , object="Case"
               , connection="OCMTEST"
     )             
public class lpocm__LP_OCM_CancelWorkflowPage {

	@BooleanType()
	@FindByLabel(label = "Not Eligible")
	public WebElement notEligible;
	@ButtonType()
	@FindByLabel(label = "Next")
	public WebElement next;
	@TextType()
	@FindBy(xpath = "//td//span")
	public WebElement CannotBeCancelled;
	@BooleanType()
	@FindByLabel(label = "Duplicate Case")
	public WebElement duplicateCase;
	@BooleanType()
	@FindByLabel(label = "Legal")
	public WebElement legal;
	
}
