package pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import com.provar.core.model.ui.api.UiFacet;
import com.provar.core.testapi.annotations.*;

@Page(title = "Console", summary = "", relativeUrl = "", connection = "OCMTEST")
public class Console {

	private WebDriver driver;

	public Console(WebDriver driver) {
		this.driver = driver;
	}

	@TextType()
	@FindBy(xpath = "//em[@class=\"x-btn-split\"]//button")
	public static WebElement TabArrow;

	public void clickArrow() {

		WebElement serviceDeskNavigatorDiv = driver.findElement(By.cssSelector("div.support-servicedesk-navigator"));
		int clickX = serviceDeskNavigatorDiv.getSize().width - 13;
		int clickY = serviceDeskNavigatorDiv.getSize().height / 2;
		Actions actions = new Actions(driver);
		actions.moveToElement(serviceDeskNavigatorDiv, clickX, clickY).click().pause(100).perform();

	}
	
	public void clickFeed(){
	WebElement feedObject = driver.findElement(By.xpath("//a[starts-with(@id,'efpViews_5000E')]"));
	Actions actions = new Actions(driver);
		actions.moveToElement(feedObject).click().pause(100).perform();
	}
	public void setSearch() {
	
	try {
		Thread.sleep(10000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		Actions builder1 = new Actions(driver);
		WebElement element = driver.findElement(By.xpath("//*[@id='phSearchInput']"));
		builder1.sendKeys(element, "test",Keys.ENTER).build().perform();
	//driver.findElement(By.xpath("//*[@id='phSearchInput']")).sendKeys("test");
	}
	public void setReportSearch() {
	WebElement reportSearch = driver.findElement(By.xpath("//*[@id='quickFindInput']"));
	Actions actions = new Actions(driver);
		actions.moveToElement(reportSearch).sendKeys("Drivers").pause(100).perform();
}
	@PageRow()
	public static class TabOptions {
		@TextType()
		@FindBy(xpath = ".")
		public WebElement Tab;

	}

	// @FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = "."), facet
	// = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//span[contains(@class, 'x-menu-item-text')]")
	@PageTable(firstRowContainsHeaders = false, row = TabOptions.class)
	public List<TabOptions> TabOptions;
	@TextType()
	@FindBy(xpath = "//tr[12]//td[1]")
	public WebElement CAP;
	@TextType()
	@FindBy(xpath = "//tr[13]//td[1]")
	public WebElement VAT;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[7]/table/tbody/tr[2]/td[3]")
	public WebElement VType;
	@ButtonType()
	@FindBy(xpath = "//*[@id=\"Account.00N0E000000Q991-_help\"]")
	public WebElement accountTeam;
	@TextType()
	@FindBy(xpath = "//tr[2]/td[2]/a")
	public WebElement AccountId;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/table/tbody/tr[3]/td[1]")
	public WebElement popup;
	@TextType()
	@FindBy(xpath = "//tr[2]/td[2]/a")
	public WebElement AccountId1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"bPageBlock\")]/div[2]/table/tbody/tr[3]/td[1]")
	public WebElement CasePopup;
	@TextType()
	@FindByLabel(label = "Registered Driver")
	public WebElement registeredDriver;
	@TextType()
	@FindBy(xpath = "//tr[3]/td/span/a")
	public WebElement registeredDriver1;
	@ButtonType()
	@FindByLabel(label = "New Ad Hoc")
	public WebElement LPOCM__LP_NewAdHocTask2;
	@ButtonType()
	@FindByLabel(label = "New Ad Hoc")
	public WebElement LPOCM__LP_NewAdHocTask21;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_5000E000004bCpF_option0\"]")
	public WebElement feed5;
	@TextType()
	@FindBy(xpath = "(//div[@class='cxfeeditem feeditem collapsed']/div[2]//div[1]/div/p)[3]")
	public WebElement FirstFeed;
	@TextType()
	@FindBy(xpath = "(//div[@class='cxfeeditem feeditem collapsed']/div[2]//div[1]/div/p)[1]")
	public WebElement Feed6;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[3]")
	public WebElement Feed7;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[4]")
	public WebElement Feed8;
	@LinkType()
	@FindBy(linkText = "\nShowAll Updates      ")
	public WebElement showAllUpdates;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"feedFilterDropDownElement\"]")
	public WebElement showAllUpdates1;
	@LinkType()
	@FindBy(linkText = "Interactions & Tasks")
	public WebElement interactionsAndTasks;
	@TextType()
	@FindBy(xpath = "(//div[@class='cxfeeditem feeditem collapsed']/div[2]//div[1]/div/p)[1]")
	public WebElement FeedT1;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[1]")
	public WebElement Feed9;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[2]")
	public WebElement Feed10;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[5]")
	public WebElement Feed11;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[6]")
	public WebElement Feed12;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[7]")
	public WebElement Feed13;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[8]")
	public WebElement Feed14;
	@TextType()
	@FindBy(xpath = "(//*[@class='cxfeeditemtextwrapper']/span)[9]")
	public WebElement Feed15;
	@ButtonType()
	@FindByLabel(label = "New Report...")
	public WebElement newReport;
	@TextType()
	@FindBy(id = "quickFindInput")
	public WebElement ReportSearch;
	@TextType()
	@FindBy(xpath = "//input[@name=\"quickFindInput\"]")
	public WebElement ReportSearch1;
	@TextType()
	@FindBy(xpath = "//input[@name=\"quickFindInput\"]")
	public WebElement ReportSearch2;
	@TextType()
	@FindBy(xpath = "//div[@class=\"x-form-field-wrap x-form-field-trigger-wrap x-trigger-wrap-focus\"][@id=\"ext-gen15\"]/input[@name=\"quickFindInput\"]")
	public WebElement SReport;
	@TextType()
	@FindBy(xpath = "//div/li[1]/div//img[1]")
	public WebElement dummyForm;
	@LinkType()
	@FindBy(linkText = "Drivers and Vehicles")
	public WebElement driversAndVehicles;
	@TextType()
	@FindBy(name = "quickFindInput")
	public WebElement Test;
	@ChoiceListType(values = { @ChoiceListValue(value = "No"), @ChoiceListValue(value = "Yes") })
	@FindByLabel(label = "Contact Authenticated")
	public WebElement contactAuthenticated;
	@BooleanType()
	@FindByLabel(label = "Send case creation notification")
	public WebElement sendCaseCreationNotification;
	@BooleanType()
	@FindByLabel(label = "Send case closure notification")
	public WebElement sendCaseClosureNotification;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[3]/table/tbody/tr[8]/td[4]")
	public WebElement ReasonForCancellation;
	@ChoiceListType(values = { @ChoiceListValue(value = "Query"), @ChoiceListValue(value = "Complaint") })
	@FindByLabel(label = "Query/Complaint")
	public WebElement queryComplaint;
	@ChoiceListType(values = { @ChoiceListValue(value = "No"), @ChoiceListValue(value = "Yes") })
	@FindBy(xpath = "//*[@id=\"CF00ND0000006B8TN_top\"]//span")
	public WebElement contactAuthenticated1;
	@ChoiceListType(values = { @ChoiceListValue(value = "No"), @ChoiceListValue(value = "Yes") })
	@FindByLabel(label = "Contact Authenticated")
	public WebElement contactAuthenticated2;
	@ChoiceListType(values = { @ChoiceListValue(value = "customer"), @ChoiceListValue(value = "driver"),
			@ChoiceListValue(value = "LeasePlan"), @ChoiceListValue(value = "no-one"),
			@ChoiceListValue(value = "supplier") })
	@FindByLabel(label = "Party at fault")
	public WebElement partyAtFault;
	@ChoiceListType(values = { @ChoiceListValue(value = "Poor Customer Service"),
			@ChoiceListValue(value = "Knowledge/Awareness"), @ChoiceListValue(value = "Legislative Change"),
			@ChoiceListValue(value = "Delayed Response"), @ChoiceListValue(value = "Supporting evidence"),
			@ChoiceListValue(value = "Process Failure - Compliance"), @ChoiceListValue(value = "System Failed"),
			@ChoiceListValue(value = "Data - Incorrect"), @ChoiceListValue(value = "Data - Missing"),
			@ChoiceListValue(value = "Misunderstanding Supplier Policy"),
			@ChoiceListValue(value = "Misunderstanding Customer Policy"),
			@ChoiceListValue(value = "Misunderstanding LP Policy"), @ChoiceListValue(value = "Poor Comms - Timing"),
			@ChoiceListValue(value = "Poor Comms - Content"), @ChoiceListValue(value = "Stock availability"),
			@ChoiceListValue(value = "Other") })
	@FindByLabel(label = "Root cause")
	public WebElement rootCause;
	@ChoiceListType(values = { @ChoiceListValue(value = "Yes"), @ChoiceListValue(value = "No") })
	@FindByLabel(label = "Preventive/corrective action needed")
	public WebElement preventiveCorrectiveActionNeeded;
	@TextType()
	@FindBy(xpath = "//tr[9]//td[4]")
	public WebElement ProcessPhase;
	@TextType()
	@FindBy(xpath = "//*[@id=\"Case.Type-_help\"]")
	public WebElement CaseType;
	@TextType()
	@FindByLabel(label = "Description")
	public WebElement Description;
	@ChoiceListType(values = { @ChoiceListValue(value = "No"), @ChoiceListValue(value = "Yes") })
	@FindByLabel(label = "Contact Authenticated")
	public WebElement LPOCM__LP_ContactAuthenticated__c;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_001D000001mEcZK_option1\"]")
	public WebElement details;
	@TextType()
	@FindBy(css = "div.listRelatedObject.contactBlock img.relatedListIcon")
	public WebElement Contacts;
	@LinkType()
	@FindBy(id = "efpViews_003D000002C8KWJ_option1")
	public WebElement details1;
	@TextType()
	@FindBy(xpath = "(//span[@class='iconFont'])[2]")
	public WebElement Vehicle_Driver_Junctions1__r;
	@TextType()
	@FindBy(xpath = "//*[@id=\"02iD000000J15P8_RelatedEntityHistoryList_title\"]")
	public WebElement RelatedEntityHistoryList;
	@TextType()
	@FindBy(xpath = "//*[@id=\"02iD000000J15P8_00ND0000005kQkF_title\"]")
	public WebElement Vehicle_Driver_Junctions__r;
	@TextType()
	@FindBy(id = "02iD000000J15P8_00ND0000004VNuT_title")
	public WebElement Cases__r;
	@TextType()
	@FindBy(xpath = "//*[@id=\"02iD000000J15P8_00ND0000006B8lZ_title\"]")
	public WebElement Vehicles1__r;
	@TextType()
	@FindBy(xpath = "//*[@id=\"Account.00ND0000006NTI7-_help\"]")
	public WebElement AccountTeam;
	@LinkType()
	@FindBy(linkText = "\n                \n                    \n                    \n                \n                Details\n                \n            ")
	public WebElement details2;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_003D000002FVZbh_option1\"]")
	public WebElement details3;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_5005E000002NOky_option1\"]")
	public WebElement details4;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[7]/table/tbody/tr[1]/td[1]")
	public WebElement Contact;
	@TextType()
	@FindBy(id = "img_01BD000000XRE7r")
	public WebElement CR;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_5005E000002NqxI_option0\"]")
	public WebElement feed;
	@LinkType()
	@FindBy(id = "efpViews_5005E000002NrLK_option0")
	public WebElement feed1;
	@LinkType()
	@FindBy(xpath = "//div[@class=\"efpPanelSelect efpsToggle efpViewSelect efpDetailsView\"]//*[@id=\"efpViews_5005E000002NsUm_option0\"]")
	public WebElement feed2;
	@TextType()
	@FindBy(xpath = "//*[@id=\"Case.00ND0000006B8VG-_help\"]")
	public WebElement SLA;
	@TextType()
	@FindBy(xpath = "//*[@id=\"Case.00ND0000006B8Vg-_help\"]")
	public WebElement TWS;
	@TextType()
	@FindBy(xpath = "//*[@id=\"Case.00ND0000006B8Vf-_help\"]")
	public WebElement TWC;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[11]/table/tbody/tr[4]/td[1]")
	public WebElement LSC;
	@TextType()
	@FindBy(id = "phSearchInput")
	public WebElement searchSalesforce;
	@TextType()
	@FindBy(xpath = "//input[@name=\"str\"]")
	public WebElement searchSalesforce1;
	@TextType()
	@FindByLabel(label = "Net Book Value(£)")
	public WebElement netBookValue;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[13]/table/tbody/tr[2]/td[2]")
	public WebElement NBV;
	@BooleanType()
	@FindByLabel(label = "NBV Manual Update")
	public WebElement LP_NBV_Manual_Update__c;
	@TextType()
	@FindBy(xpath = "//span[contains(@class, \"searchFirstCell\")]")
	public WebElement MODAccounts;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"dataRow\")]//td[3]")
	public WebElement Lessee_Number__c;
	@TextType()
	@FindBy(xpath = "//*[@id=\"Account_body\"]/table/tbody/tr[2]/td[3]")
	public WebElement Lessee_Number__c1;
	@TextType()
	@FindBy(xpath = "(//span[@class='iconFont'])[2]")
	public WebElement contactDetails;
	@LinkType()
	@FindBy(xpath = "//a[starts-with(@id,'efpViews_5')]")
	public WebElement feed3;
	@TextType()
	@FindBy(xpath = "(//p[starts-with(@class,'summarydes')])[2]")
	public WebElement postCase;


}
