package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.model.ui.api.UiFacet;
import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Assets Tab"                                
               , summary=""
               , page="AssetsTab"
               , namespacePrefix=""
               , object="Asset"
               , connection="OCMTEST"
     )             
public class AssetsTab {

	@LinkType()
	@FindBy(xpath = "//*[@id=\"02iD000000My96O_ASSET_NAME\"]//a")
	public WebElement _101XAL9890108;
	@TextType()
	@FindBy(xpath = "//*[@id=\"02iD000000OrgZ1_00ND0000004VXLX\"]")
	public WebElement AllAssets_listBody;
	@TextType()
	@FindByLabel(label = "Car", labelType = LabelType.RelativeTo, controlXpath = "ancestor::div[1]/following-sibling::div[1]//td/div", labelXpath = "//*[@id=\"02iD000000My96O_00ND0000004VXLY\"]")
	public WebElement AllAssets_listBody1;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[3]/div")
	public WebElement AllAssets_listBody2;
	@LinkType()
	@FindBy(linkText = "YY66WZE-1094501")
	public WebElement yY66WZE1094501;
	@LinkType()
	@FindBy(linkText = "Y")
	public WebElement y;
	@LinkType()
	@FindBy(linkText = "A")
	public WebElement a;
	@LinkType()
	@FindBy(linkText = "Y")
	public WebElement y1;
	@LinkType()
	@FindBy(linkText = "C")
	public WebElement c;
	@LinkType()
	@FindBy(linkText = "BG14UKH-1121553")
	public WebElement bG14UKH1121553;
	@LinkType()
	@FindBy(linkText = "BL65HEU-1011533")
	public WebElement bL65HEU1011533;
	
	
	@PageRow()
	public static class VehicleTable {
	
	@LinkType()
	@FindBy(xpath = ".//td[3]//a")
	public WebElement VehicleName;
	
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//table[contains(@class,'row-table')]")
	@PageTable(firstRowContainsHeaders = false, row = VehicleTable.class)
	public List<VehicleTable> VehicleTable;
	
	
	@LinkType()
	@FindBy(xpath = "//*[@id=\"02iD000000Mxp1x_ASSET_NAME\"]//a")
	public WebElement vn;
	@LinkType()
	@FindBy(linkText = "Create New View")
	public WebElement createNewView;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[4]/div")
	public WebElement AllAssets_listBody3;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[5]/div")
	public WebElement AllAssets_listBody4;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[6]/div")
	public WebElement AllAssets_listBody5;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[7]/div")
	public WebElement AllAssets_listBody6;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[8]/div")
	public WebElement AllAssets_listBody7;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[9]/div")
	public WebElement AllAssets_listBody8;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[10]/div")
	public WebElement AllAssets_listBody9;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[11]/div")
	public WebElement AllAssets_listBody10;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[12]/div")
	public WebElement AllAssets_listBody11;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[13]/div")
	public WebElement AllAssets_listBody12;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[14]/div")
	public WebElement AllAssets_listBody13;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[15]/div")
	public WebElement AllAssets_listBody14;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[16]/div")
	public WebElement AllAssets_listBody15;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[17]/div")
	public WebElement AllAssets_listBody16;
	@ChoiceListType(values = { @ChoiceListValue(value = "All Vehicles"), @ChoiceListValue(value = "CAR_Marginal"),
			@ChoiceListValue(value = "Car_Qualify"), @ChoiceListValue(value = "LCV"),
			@ChoiceListValue(value = "Renewal Within Next 6 Months"), @ChoiceListValue(value = "Truck") })
	@FindBy(name = "j_id0:AllAssets:fcf")
	public WebElement AllAssets_listSelect;
	
}
