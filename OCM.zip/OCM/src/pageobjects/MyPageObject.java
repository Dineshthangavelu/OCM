package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="MyPageObject"                                
     , summary=""
     , relativeUrl=""
     , connection="KalaiAdmin"
     )             
public class MyPageObject {

	@TextType()
	@FindByLabel(label = "Quick Find")
	public WebElement quickFind;
	@LinkType()
	@FindBy(linkText = "Custom Metadata Types")
	public WebElement customMetadataTypes;
	@LinkType()
	@FindBy(linkText = "CAP Endpoint")
	public WebElement cAPEndpoint;
	@ButtonType()
	@FindByLabel(label = "Manage CAP Endpoint")
	public WebElement manageCAPEndpoint;
	@LinkType()
	@FindBy(linkText = "Edit")
	public WebElement edit;
	@TextType()
	@FindByLabel(label = "CustCode")
	public WebElement custCode;
	@LinkType()
	@FindBy(id = "globalHeaderNameMink")
	public WebElement kalaivaananGaneasan;
	@LinkType()
	@FindBy(linkText = "Setup")
	public WebElement setup;
	@TextType()
	@FindByLabel(label = "Password")
	public WebElement password;
			
}
