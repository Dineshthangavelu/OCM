package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Lpocm__ LP_ OCM_ Case Categorize Page"                                
               , summary=""
               , page="LP_OCM_CaseCategorizePage"
               , namespacePrefix="LPOCM"
               , object="Case"
               , connection="OCMTEST"
     )             
public class lpocm__LP_OCM_CaseCategorizePage {

	@BooleanType()
	@VisualforceBy(componentXPath = "apex:SelectOptions[@value = \"{!radioValues}\"]")
	public WebElement delivery;
	@BooleanType()
	@VisualforceBy(componentXPath = "apex:SelectOptions[@value = \"{!radioValues2}\"]")
	public WebElement reportAccident;
	@VisualforceBy(componentXPath = "apex:pageBlockSectionItem[5]/apex:inputField[@id='cont']")
	@SalesforceField(name = "LPOCM__LP_CaseVehicle__c", object = "Case")
	public WebElement vehicle;
	@VisualforceBy(componentXPath = "apex:inputField[@id='descfield']")
	@SalesforceField(name = "Description", object = "Case")
	public WebElement description;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@id='saveDraft']")
	public WebElement saveDraftAndEdit;
	@BooleanType()
	@FindBy(xpath = "//table[contains(@class, \"showHover\")]/tbody/tr[3]/td/input")
	public WebElement delivery1;
	@BooleanType()
	@FindBy(id = "cpage:cform:cblock:j_id41:j_id46:valSelector2:2")
	public WebElement RFS;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about vehicle delivery")
	public WebElement queryComplaintAboutVehicleDelivery;
	@PageTable(row = CC.class)
	@VisualforceBy(componentXPath = "apex:pageBlockTable[@id='checkboxLoop']")
	public List<CC> CC;
	@PageRow(byColumn = true)
	public static class CC {

		@BooleanType()
		@FindBy(id = "cpage:cform:cblock:Classification:checkboxLoop:5:checkboxComp")
		public WebElement field1;
		@BooleanType()
		@FindBy(xpath = "//input[@name=\"cpage:cform:cblock:Classification:checkboxLoop:7:checkboxComp\"]")
		public WebElement field11;
		@BooleanType()
		@FindBy(xpath = "//input[@name=\"cpage:cform:cblock:Classification:checkboxLoop:6:checkboxComp\"]")
		public WebElement field12;
		@BooleanType()
		@FindBy(id = "cpage:cform:cblock:Classification:checkboxLoop:0:checkboxComp")
		public WebElement field13;
		@BooleanType()
		@FindBy(xpath = "//input[@name=\"cpage:cform:cblock:Classification:checkboxLoop:0:checkboxComp\"]")
		public WebElement field14;
	}
	@BooleanType()
	@FindByLabel(label = "Information on vehicle delivery")
	public WebElement informationOnVehicleDelivery;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about vehicle delivery")
	public WebElement queryComplaintAboutVehicleDelivery1;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about vehicle delivery")
	public WebElement queryComplaintAboutVehicleDelivery2;
	@BooleanType()
	@FindByLabel(label = "Lease Contract Set-up")
	public WebElement leaseContractSetUp;
	@BooleanType()
	@FindByLabel(label = "Request novation")
	public WebElement requestNovation;
	@TextType()
	@FindBy(xpath = "//h2[contains(@class, \"mainTitle\")]")
	public WebElement cblock;
	@TextType()
	@FindBy(xpath = "//tr[1]/th/span/label")
	public WebElement cpageCformCblockJId41AdditionalFieldsJId51JId52HelpTextHelp;
	@TextType()
	@FindBy(xpath = "//tr[2]/th/span/label")
	public WebElement Contact;
	@TextType()
	@FindBy(xpath = "//tr[3]/th/span/label")
	public WebElement RegisteredDriver;
	@TextType()
	@FindBy(xpath = "//tr[4]/th/span/label")
	public WebElement Vehicle;
	@TextType()
	@FindBy(xpath = "//tr[5]/th/span/label")
	public WebElement InitiatedBy;
	@ButtonType()
	@FindByLabel(label = "Cancel")
	public WebElement cancel;
	@BooleanType()
	@FindByLabel(label = "Accident")
	public WebElement accident;
	@TextType()
	@FindBy(xpath = "//td[contains(@class, \"colStyle2\")]/fieldset/table/tbody/tr[2]/td/label")
	public WebElement valSelector2;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about accident services")
	public WebElement queryComplaintAboutAccidentServices;
	@TextType()
	@FindBy(xpath = "//h3")
	public WebElement Classification;
	@TextType()
	@FindBy(xpath = "//td[contains(@class, \"colStyle2\")]/fieldset/table/tbody/tr[1]/td/label")
	public WebElement valSelector21;
	@BooleanType()
	@FindByLabel(label = "Information on accident")
	public WebElement informationOnAccident;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@id='saveClose']")
	public WebElement saveAndClose;
	@TextType()
	@FindBy(xpath = "//td[contains(@class, \"colStyle2\")]/fieldset/table/tbody/tr[3]/td/label")
	public WebElement valSelector22;
	@TextType()
	@FindBy(xpath = "//td[contains(@class, \"colStyle2\")]/fieldset/table/tbody/tr[8]/td/label")
	public WebElement valSelector23;
	@BooleanType()
	@FindByLabel(label = "Request novation")
	public WebElement requestNovation1;
	@BooleanType()
	@FindByLabel(label = "Lease Contract Termination")
	public WebElement leaseContractTermination;
	@BooleanType()
	@FindByLabel(label = "Request early termination quote")
	public WebElement requestEarlyTerminationQuote;
	@VisualforceBy(componentXPath = "apex:pageBlockSectionItem[5]/apex:inputField[@id='cont']")
	@SalesforceField(name = "LPOCM__LP_CaseVehicle__c", object = "Case")
	public WebElement cont;
	@TextType()
	@FindBy(xpath = "//tr[4]/td/span/a")
	public WebElement cont1;
	@TextType()
	@FindByLabel(label = "Registered Driver")
	public WebElement registeredDriver;
	@BooleanType()
	@FindByLabel(label = "Quote")
	public WebElement quote;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about new vehicle Quote")
	public WebElement queryComplaintAboutNewVehicleQuote;
	@BooleanType()
	@FindByLabel(label = "Vehicle Tax & Documents")
	public WebElement vehicleTaxAndDocuments;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about authority letter")
	public WebElement queryComplaintAboutAuthorityLetter;
	@BooleanType()
	@FindByLabel(label = "Fines and tolls")
	public WebElement finesAndTolls;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about fine or toll")
	public WebElement queryComplaintAboutFineOrToll;
	@BooleanType()
	@FindByLabel(label = "Fuel & Card Services")
	public WebElement fuelAndCardServices;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about fuel card")
	public WebElement queryComplaintAboutFuelCard;
	@BooleanType()
	@FindByLabel(label = "Information on quotation")
	public WebElement informationOnQuotation;
	@BooleanType()
	@FindByLabel(label = "Start of contract")
	public WebElement startOfContract;
	@BooleanType()
	@FindByLabel(label = "Information on authority letter")
	public WebElement informationOnAuthorityLetter;
	@BooleanType()
	@FindByLabel(label = "Request authority letter")
	public WebElement requestAuthorityLetter;
	@BooleanType()
	@FindByLabel(label = "Information on vehicle documents")
	public WebElement informationOnVehicleDocuments;
	@BooleanType()
	@FindBy(xpath = "//td[contains(@class, \"colStyle2\")]/fieldset/table/tbody/tr[3]/td/label")
	public WebElement informationOnVehicleDelivery1;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about vehicle documents")
	public WebElement queryComplaintAboutVehicleDocuments;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about vehicle tax")
	public WebElement queryComplaintAboutVehicleTax;
	@BooleanType()
	@FindByLabel(label = "Request vehicle documents")
	public WebElement requestVehicleDocuments;
	@BooleanType()
	@FindByLabel(label = "Request vehicle taxing")
	public WebElement requestVehicleTaxing;
	@BooleanType()
	@FindByLabel(label = "Other vehicle services")
	public WebElement otherVehicleServices;
	@BooleanType()
	@FindByLabel(label = "Request personalised plates")
	public WebElement requestPersonalisedPlates;
	@BooleanType()
	@FindByLabel(label = "Lease Contract in Life")
	public WebElement leaseContractInLife;
	@BooleanType()
	@FindByLabel(label = "Request change of customer details")
	public WebElement requestChangeOfCustomerDetails;
	@BooleanType()
	@FindByLabel(label = "Information on change customer details")
	public WebElement informationOnChangeCustomerDetails;
	@BooleanType()
	@FindByLabel(label = "Information on create/amend cost centre")
	public WebElement informationOnCreateAmendCostCentre;
	@BooleanType()
	@FindByLabel(label = "Information on vehicle contract details")
	public WebElement InfomationonVehicleContractDetails;
	@BooleanType()
	@FindByLabel(label = "Query/Complaint about cost centre")
	public WebElement queryComplaintAboutCostCentre;
	
}
