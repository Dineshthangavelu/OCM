package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Lpocm__ LP_ OCM_ New Workflow Task Page"                                
               , summary=""
               , page="LP_OCM_NewWorkflowTaskPage"
               , namespacePrefix="LPOCM"
               , object="Case"
               , connection="OCMTEST"
     )             
public class lpocm__LP_OCM_NewWorkflowTaskPage {

	@TextType()
	@FindBy(name = "j_id0:j_id1:i:f:pb:d:element___input____Ad_Hoc_Task_Name")
	public WebElement Ad_Hoc_Task_Name_input;
	@BooleanType()
	@FindByLabel(label = "LPUK EC1 Team Queue")
	public WebElement lPUKEC1TeamQueue;
	@ButtonType()
	@FindByLabel(label = "Next")
	public WebElement next;
	@BooleanType()
	@FindByLabel(label = "LPUK EC5 Team Queue")
	public WebElement lPUKEC5TeamQueue;
	
}
