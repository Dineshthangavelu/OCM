package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Lpocm__ LP_ OCM_ New Workflow Action Page"                                
               , summary=""
               , page="LP_OCM_NewWorkflowActionPage"
               , namespacePrefix="LPOCM"
               , object="LPOCM__LP_OperationalTask__c"
               , connection="OCMTEST"
     )             
public class lpocm__LP_OCM_NewWorkflowActionPage {

	@BooleanType()
	@FindByLabel(label = "Done via phone")
	public WebElement doneViaPhone;
	@ButtonType()
	@FindByLabel(label = "Next")
	public WebElement next;
	@BooleanType()
	@FindByLabel(label = "Confirmed; Deliver Service")
	public WebElement confirmedDeliverService;
	@BooleanType()
	@FindByLabel(label = "Done")
	public WebElement done;
	@BooleanType()
	@FindByLabel(label = "Confirmed; deliver service")
	public WebElement confirmedDeliverService1;
	@BooleanType()
	@FindByLabel(label = "Check with legal")
	public WebElement checkWithLegal;
	@BooleanType()
	@FindByLabel(label = "Review Documents")
	public WebElement reviewDocuments;
	@BooleanType()
	@FindByLabel(label = "Send Documents to customer")
	public WebElement sendDocumentsToCustomer;
	@BooleanType()
	@FindByLabel(label = "Send to Legal")
	public WebElement sendToLegal;
	@BooleanType()
	@FindByLabel(label = "Update Systems")
	public WebElement updateSystems;
	@TextType()
	@FindBy(xpath = "//tbody/tr[7]/td/span/span/font")
	public WebElement FieldValidationError;
	@TextType()
	@FindBy(name = "j_id0:j_id1:i:f:pb:d:element___input____Post_case_note")
	public WebElement Post_case_note_input;
	@BooleanType()
	@FindByLabel(label = "Wrong Data")
	public WebElement wrongData;
	@BooleanType()
	@FindByLabel(label = "Approved; cancel case")
	public WebElement approvedCancelCase;
	@BooleanType()
	@FindByLabel(label = "Rejected; continue case fulfilment")
	public WebElement rejectedContinueCaseFulfilment;
	
}
