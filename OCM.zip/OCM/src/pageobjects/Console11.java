package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="Console11"                                
     , summary=""
     , relativeUrl=""
     , connection="OCMTEST"
     )             
public class Console11 {

	@TextType()
	@FindBy(xpath = "//input[@id='quickFindInput']")
	public WebElement ReportSearch;
			
}
