package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="OCM"                                
     , summary=""
     , relativeUrl=""
     , connection="OCMTEST"
     )             
public class OCM {

	@LinkType()
	@FindBy(linkText = "Back to Operational Service")
	public WebElement backToOperationalService;
	@TextType()
	@FindBy(id = "ext-gen188")
	public WebElement MainDD;
	@TextType()
	@FindBy(id = "ext-gen188")
	public WebElement DD;
	@ButtonType()
	@FindByLabel(label = "Cases")
	public WebElement casesTab;
	@LinkType()
	@FindBy(linkText = "Back to Operational Service")
	public WebElement backToOperationalService1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"searchBar\")]")
	public WebElement HomeDD;
	@LinkType()
	@FindBy(linkText = "Cases")
	public WebElement cases;
	@LinkType()
	@FindBy(linkText = "000067e, f754")
	public WebElement _000067EF754;
	@LinkType()
	@FindBy(linkText = "\n                \n                    \n                    \n                \n                Details\n                \n            ")
	public WebElement details;
	@LinkType()
	@FindBy(linkText = "\n                \n                    \n                    \n                \n                Details\n                \n            ")
	public WebElement details1;
	@LinkType()
	@FindBy(linkText = "\n                \n                    \n                    \n                \n                Details\n                \n            ")
	public WebElement details2;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[4]/div")
	public WebElement CaseNumber;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[3]/div")
	public WebElement Action;
	@ButtonType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[5]/div")
	public WebElement ContactName;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[6]/div")
	public WebElement Subject;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[7]/div")
	public WebElement CaseStatus;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[8]/div")
	public WebElement Priority;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"ext-gen22\"]//div")
	public WebElement CreatedDate;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[10]/div")
	public WebElement Owner_NameOrAlias;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[9]/div")
	public WebElement DateTimeOpened;
	@TextType()
	@FindBy(xpath = "//*[@id=\"p:i:i:f:pb:d:Screen1\"]")
	public WebElement Screen1;
	@ButtonType()
	@FindByLabel(label = "Next")
	public WebElement next;
	@ButtonType()
	@FindByLabel(label = "Home")
	public WebElement home;
	@ButtonType()
	@FindByLabel(label = "Accounts")
	public WebElement accounts;
	@ButtonType()
	@FindByLabel(label = "Contacts")
	public WebElement contacts;
	@ButtonType()
	@FindByLabel(label = "Vehicles")
	public WebElement vehicles;
	@ButtonType()
	@FindByLabel(label = "Contracts")
	public WebElement contracts;
	@ButtonType()
	@FindByLabel(label = "Cases")
	public WebElement cases1;
	@ButtonType()
	@FindByLabel(label = "Operational Tasks")
	public WebElement operationalTasks;
	@ButtonType()
	@FindByLabel(label = "Reports")
	public WebElement reports;
	@ButtonType()
	@FindByLabel(label = "Dashboards")
	public WebElement dashboards;
	@ButtonType()
	@FindByLabel(label = "Chatter")
	public WebElement chatter;
	@ButtonType()
	@FindByLabel(label = "Knowledge")
	public WebElement knowledge;
	@TextType()
	@FindBy(xpath = "//td[contains(@class, \"pbTitle\")]//h3")
	public WebElement MyTasks;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[3]/div")
	public WebElement Account;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_4_ep\"]//h3")
	public WebElement DriverCustomerToBuy;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[9]/table/tbody/tr[1]/td[1]/label")
	public WebElement FinalCostToDriver;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[9]/table/tbody/tr[2]/td[1]/label")
	public WebElement FinalCostToCustomer;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[9]/table/tbody/tr[1]/td[3]/label")
	public WebElement ETQValueforDTB;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[9]/table/tbody/tr[2]/td[3]/label")
	public WebElement DTBValue;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_5_ep\"]//h3")
	public WebElement ETGeneralInformation;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[11]/table/tbody/tr[1]/td[1]/label")
	public WebElement ActualMileage;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[11]/table/tbody/tr[1]/td[3]/label")
	public WebElement ETDate;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[11]/table/tbody/tr[2]/td[1]/label")
	public WebElement EarlyTerminationPayee;
	@TextType()
	@FindBy(xpath = "//*[@id=\"Case.00ND0000006B8SK-_help\"]//label")
	public WebElement ETCalculationMethod;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[11]/table/tbody/tr[3]/td[1]/label")
	public WebElement ETQValue;
	@TextType()
	@FindBy(xpath = "//tr[3]/td[3]/label")
	public WebElement VehicleDisposal;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[11]/table/tbody/tr[4]/td[1]/label")
	public WebElement ETQReason;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_6_ep\"]//h3")
	public WebElement TrueLossCalculation;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[13]/table/tbody/tr[1]/td[3]/label")
	public WebElement CAPValue;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[13]/table/tbody/tr[2]/td[1]/label")
	public WebElement NetBookValue;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_7_ep\"]//h3")
	public WebElement OS_Rentals_Calculation;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[15]/table/tbody/tr/td[1]/label")
	public WebElement OutstandingRentalsPercentage;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[9]/table/tbody/tr[1]/td[1]")
	public WebElement FinalCosttoDriver;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[9]/table/tbody/tr[1]/td[3]")
	public WebElement ETQValueforDTB1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[9]/table/tbody/tr[2]/td[1]")
	public WebElement FinalCosttoCustomer;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[9]/table/tbody/tr[2]/td[3]")
	public WebElement DTBValue1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[11]/table/tbody/tr[3]/td[1]")
	public WebElement ETQValue1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[11]/table/tbody/tr[4]/td[1]")
	public WebElement ETQReason1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[13]/table/tbody/tr[1]/td[1]")
	public WebElement AuctionValue;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[13]/table/tbody/tr[1]/td[3]")
	public WebElement CAPValue1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[13]/table/tbody/tr[2]/td[1]")
	public WebElement NetBookValue1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"efdFields\")]/div[15]/table/tbody/tr/td[1]")
	public WebElement OutstandingRentalsPercentage1;
	@TextType()
	@FindBy(xpath = "//tr[12]//td[1]")
	public WebElement CAPID;
	@TextType()
	@FindBy(xpath = "//tr[13]//td[1]")
	public WebElement VATStatus;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[7]/table/tbody/tr[2]/td[3]")
	public WebElement VehicleType;
	@TextType()
	@FindBy(xpath = "//input[@name=\"str\"]")
	public WebElement searchSalesforce;
	@TextType()
	@FindBy(xpath = "//input[@name=\"str\"]")
	public WebElement searchSalesforce1;
	@TextType()
	@FindBy(id = "phSearchInput")
	public WebElement searchSalesforce11;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"searchBoxClearContainer\")]")
	public WebElement Search;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"searchBoxClearContainer\")]")
	public WebElement SearchSF;
	@TextType()
	@FindBy(id = "ext-gen239")
	public WebElement Accordion;
	@TextType()
	@FindBy(id = "ext-gen239")
	public WebElement verticalScroll;
	@TextType()
	@FindBy(id = "ext-comp-1033-xcollapsed")
	public WebElement Accor;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[2]/div")
	public WebElement Action1;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[3]/div")
	public WebElement AccountName;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[4]/div")
	public WebElement MAINCOUNTRY;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[5]/div")
	public WebElement Phone;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[6]/div")
	public WebElement Type;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[7]/div")
	public WebElement Owner_Alias;
	@TextType()
	@FindBy(xpath = "//h2[contains(@class, \"mainTitle\")]")
	public WebElement Account_Detail;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7S_ep\"]//h3")
	public WebElement Address;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7T_ep\"]//h3")
	public WebElement FleetInformation;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7U_ep\"]//h3")
	public WebElement CreditInformation;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7W_ep\"]//h3")
	public WebElement SystemInformation;
	@TextType()
	@FindBy(id = "001D000001RP23a_RelatedContactList_title")
	public WebElement Contacts;
	@TextType()
	@FindBy(id = "001D000001RP23a_RelatedCaseList_title")
	public WebElement Cases;
	@TextType()
	@FindBy(id = "001D000001RP23a_00ND0000004UwXK_title")
	public WebElement CostCentres;
	@TextType()
	@FindBy(id = "001D000001RP23a_RelatedActivityList_title")
	public WebElement OpenActivities;
	@TextType()
	@FindBy(id = "001D000001RP23a_RelatedHistoryList_title")
	public WebElement MyTasks1;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_001D000001RP23a_option1\"]")
	public WebElement details3;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"00B0E000000ZY9D_rolodex\"]//a[1]")
	public WebElement a;
	@ButtonType()
	@FindBy(id = "00B0E000000ZY9D_refresh")
	public WebElement Refresh;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[2]/div")
	public WebElement Action2;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[3]/div")
	public WebElement Account_Name;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[4]/div")
	public WebElement Name;
	@LinkType()
	@FindBy(id = "ext-gen22")
	public WebElement Title;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[6]/div")
	public WebElement Email;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[7]/div")
	public WebElement Mobile;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[8]/div")
	public WebElement Phone1;
	@TextType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[9]/div")
	public WebElement MainContact;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[10]/div")
	public WebElement CreatedDate1;
	@LinkType()
	@FindBy(id = "efpViews_0030E0000096ivs_option1")
	public WebElement details4;
	@TextType()
	@FindBy(xpath = "//h2[contains(@class, \"mainTitle\")]")
	public WebElement ContactDetail;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XREE1_ep\"]//h3")
	public WebElement CoreLeasingInformation;
	@TextType()
	@FindBy(id = "0030E0000096ivs_00ND0000005kQkG_title")
	public WebElement Vehicles;
	@TextType()
	@FindBy(id = "0030E0000096ivs_RelatedCaseList_title")
	public WebElement MyTasks2;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[5]/div")
	public WebElement JobTitle;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7b_ep\"]//h3")
	public WebElement VehicleInformation;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7d_ep\"]//h3")
	public WebElement ContractDetails;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7e_ep\"]//h3")
	public WebElement VehicleGeneralInformation;
	@TextType()
	@FindBy(id = "02iD000000MxtRI_RelatedEntityHistoryList_title")
	public WebElement AssetHistory;
	@TextType()
	@FindBy(id = "02iD000000MxtRI_00ND0000005kQkF_title")
	public WebElement VehicleDriver;
	@TextType()
	@FindBy(id = "02iD000000MxtRI_00ND0000004VNuT_title")
	public WebElement Cases1;
	@TextType()
	@FindBy(id = "02iD000000MxtRI_00ND0000006B8lZ_title")
	public WebElement Vehicles1;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/div[5]/table/tbody/tr[4]/td[3]")
	public WebElement LinkToContractDetails;
	@TextType()
	@FindBy(xpath = "//*[@id=\"lookup800D0000003CxRI00ND0000004UwOw\"]")
	public WebElement NOLS_Contract__c;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/table/tbody/tr[1]/td[1]")
	public WebElement Accountname;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"contractBlock\")]/div/div[2]/table/tbody/tr[2]/td[1]")
	public WebElement Status;
	@TextType()
	@FindBy(xpath = "//div[contains(@class, \"pbBody\")]/table/tbody/tr[3]/td[1]")
	public WebElement AccidentManagement;
	@TextType()
	@FindBy(xpath = "//h1[contains(@class, \"pageType\")]")
	public WebElement Contract;
	@TextType()
	@FindBy(linkText = "00065063")
	public WebElement NOLS_Contract__c1;
	@ButtonType()
	@FindByLabel(label = "Edit")
	public WebElement Edit;
	@ButtonType()
	@FindBy(name = "edit")
	public WebElement EditButton;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_5000E000004bCkU_option0\"]")
	public WebElement feed;
	@TextType()
	@FindBy(xpath = "//*[@id=\"0D50E000005jT6a\"]/div[2]/div[1]/div[1]/div/p")
	public WebElement Feed1;
	@TextType()
	@FindBy(xpath = "//*[@id=\"0D50E000005jT6f\"]/div[2]/div[2]/div[1]/div[2]/span")
	public WebElement Feed2;
	@LinkType()
	@FindBy(id = "efpViews_5000E000004bClD_option0")
	public WebElement feed1;
	@TextType()
	@FindBy(xpath = "//*[@id=\"0D50E000005jT7T\"]/div[2]/div[2]/div[1]/div[2]/span")
	public WebElement Feed3;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_5000E000004bCmG_option0\"]")
	public WebElement feed2;
	@TextType()
	@FindBy(xpath = "//*[@id=\"0D50E000005jTBV\"]/div[2]/div[1]/div[1]/div/p")
	public WebElement Feed;
	@TextType()
	@FindBy(xpath = "//*[@id=\"0D50E000005jTBa\"]/div[2]/div[1]/div[1]/div/p")
	public WebElement Feed4;
	@LinkType()
	@FindBy(linkText = "\n                \n                    \n                    \n                \n                Feed\n                \n            ")
	public WebElement feed3;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"efpViews_5000E000004bCo7_option0\"]")
	public WebElement feed4;
	@ButtonType()
	@FindByLabel(label = "New Report...")
	public WebElement newReport;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7o_ep\"]//h3")
	public WebElement RelatedTo;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7p_ep\"]//h3")
	public WebElement AdditionalInformation;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7q_ep\"]//h3")
	public WebElement CC;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7r_ep\"]//h3")
	public WebElement CR;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7t_ep\"]//h3")
	public WebElement SLA;
	@TextType()
	@FindBy(xpath = "//*[@id=\"head_01BD000000XRE7v_ep\"]//h3")
	public WebElement CaseNotification;
	@TextType()
	@FindBy(id = "img_01BD000000XRE7r")
	public WebElement CRButton;
	@ChoiceListType(values = { @ChoiceListValue(value = "Query"), @ChoiceListValue(value = "Complaint") })
	@FindByLabel(label = "Query/Complaint", labelType = LabelType.PrecedingCell)
	public WebElement queryComplaint;
	@ChoiceListType(values = { @ChoiceListValue(value = "Query"), @ChoiceListValue(value = "Complaint") })
	@FindByLabel(label = "Query/Complaint")
	public WebElement queryComplaint1;
	@ButtonType()
	@FindByLabel(label = "Edit")
	public WebElement Edit1;
	@TextType()
	@FindBy(id = "phSearchInput")
	public WebElement searchSalesforce2;
	@TextType()
	@FindBy(xpath = "//input[@name=\"str\"]")
	public WebElement searchSalesforce3;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[3]/div")
	public WebElement Name1;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"ext-gen24\"]")
	public WebElement Owner_Alias1;
	@LinkType()
	@FindBy(xpath = "//tr[contains(@class, \"x-grid3-hd-row\")]/td[8]/div")
	public WebElement Owner_Alias2;
			
}
